#ifndef LEXICO_C_SINTATICO_H
#define LEXICO_C_SINTATICO_H

#include "pilha.h"

int parser(int input_token, int stack_token, Stack *stack);

#endif //LEXICO_C_SINTATICO_H
